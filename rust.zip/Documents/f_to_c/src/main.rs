use std::io;

fn main() {
    println!("Enter temperature in Fahrenheit to convert it to Celsius");
    let mut f = String::new();
    io::stdin().read_line(&mut f).expect("Failet to read line");
    let x = f.trim().parse::<f32>().expect("Failed parsing int");
    let celsius = (x - 32.0) / 1.8;
    println!("{}", celsius);
}